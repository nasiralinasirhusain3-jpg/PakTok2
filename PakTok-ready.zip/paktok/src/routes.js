'use strict';
// تمام API راستے (routes)
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Transform } = require('stream');
const { pipeline } = require('stream/promises');

const { db, notify } = require('./db');
const cfg = require('./config');
const auth = require('./auth');
const { HttpError, sendJson, readJson, parseCookies, clientIp, rateLimit } = require('./http');

// ---------- جانچ (validation) ----------
const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const str = (v) => (typeof v === 'string' ? v.trim() : '');

function publicUser(u) {
  return {
    id: u.id, username: u.username, display_name: u.display_name || u.username,
    bio: u.bio, role: u.role,
  };
}

function currentUser(req) {
  const payload = auth.verifyToken(parseCookies(req)[auth.COOKIE]);
  if (!payload) return null;
  const u = db
    .prepare('SELECT id, username, email, display_name, bio, role, status FROM users WHERE id = ?')
    .get(payload.id);
  return u && u.status === 'active' ? u : null;
}

const isStaff = (u) => !!u && (u.role === 'moderator' || u.role === 'super_admin');

function requireUser(ctx) {
  if (!ctx.user) throw new HttpError(401, 'پہلے لاگ اِن کریں');
  return ctx.user;
}
function requireStaff(ctx) {
  const u = requireUser(ctx);
  if (!isStaff(u)) throw new HttpError(403, 'آپ کو اجازت نہیں');
  return u;
}
function requireSuper(ctx) {
  const u = requireUser(ctx);
  if (u.role !== 'super_admin') throw new HttpError(403, 'صرف سپر ایڈمن یہ کام کر سکتا ہے');
  return u;
}

const idParam = (v) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1) throw new HttpError(400, 'غلط شناخت');
  return n;
};

// ---------- اکاؤنٹ ----------
async function register(ctx) {
  rateLimit(`reg:${clientIp(ctx.req)}`, 10, 60 * 60 * 1000);
  const b = await readJson(ctx.req);
  const username = str(b.username);
  const email = str(b.email).toLowerCase();
  const password = typeof b.password === 'string' ? b.password : '';

  if (!USERNAME_RE.test(username))
    throw new HttpError(400, 'یوزر نیم 3 سے 20 حروف کا ہو (انگریزی حروف، ہندسے یا _)');
  if (!EMAIL_RE.test(email) || email.length > 120) throw new HttpError(400, 'ای میل درست نہیں');
  if (password.length < 8 || password.length > 100)
    throw new HttpError(400, 'پاسورڈ کم از کم 8 حروف کا ہو');

  if (db.prepare('SELECT 1 FROM users WHERE username = ? OR email = ?').get(username, email))
    throw new HttpError(409, 'یہ یوزر نیم یا ای میل پہلے سے موجود ہے');

  const role = cfg.ADMIN_EMAIL && email === cfg.ADMIN_EMAIL ? 'super_admin' : 'user';
  const hash = await auth.hashPassword(password);
  let id;
  try {
    id = db
      .prepare('INSERT INTO users (username, email, password_hash, display_name, role) VALUES (?,?,?,?,?)')
      .run(username, email, hash, username, role).lastInsertRowid;
  } catch (e) {
    if (String(e.message).includes('UNIQUE'))
      throw new HttpError(409, 'یہ یوزر نیم یا ای میل پہلے سے موجود ہے');
    throw e;
  }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  sendJson(ctx.res, 201, { user: publicUser(user) }, {
    'Set-Cookie': auth.sessionCookie(auth.createToken(user.id)),
  });
}

async function login(ctx) {
  const ip = clientIp(ctx.req);
  rateLimit(`login-ip:${ip}`, 30, 15 * 60 * 1000);
  const b = await readJson(ctx.req);
  const id = str(b.login).toLowerCase();
  const password = typeof b.password === 'string' ? b.password : '';
  if (!id || !password) throw new HttpError(400, 'ای میل اور پاسورڈ لکھیں');
  rateLimit(`login-id:${id}`, 8, 15 * 60 * 1000);

  const user = db.prepare('SELECT * FROM users WHERE email = ? OR username = ?').get(id, id);
  const ok = await auth.verifyPassword(password, user ? user.password_hash : auth.DUMMY_HASH);
  if (!user || !ok) throw new HttpError(401, 'ای میل/یوزر نیم یا پاسورڈ غلط ہے');
  if (user.status !== 'active') throw new HttpError(403, 'یہ اکاؤنٹ بند کر دیا گیا ہے');

  sendJson(ctx.res, 200, { user: publicUser(user) }, {
    'Set-Cookie': auth.sessionCookie(auth.createToken(user.id)),
  });
}

function logout(ctx) {
  sendJson(ctx.res, 200, { ok: true }, { 'Set-Cookie': auth.clearCookie() });
}

function me(ctx) {
  if (!ctx.user) return sendJson(ctx.res, 200, { user: null });
  const unread = db
    .prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(ctx.user.id).n;
  sendJson(ctx.res, 200, { user: publicUser(ctx.user), unread });
}

async function updateMe(ctx) {
  const u = requireUser(ctx);
  const b = await readJson(ctx.req);
  const display = str(b.display_name).slice(0, 40) || u.username;
  const bio = str(b.bio).slice(0, 300);
  db.prepare('UPDATE users SET display_name = ?, bio = ? WHERE id = ?').run(display, bio, u.id);
  sendJson(ctx.res, 200, { user: publicUser({ ...u, display_name: display, bio }) });
}

// ---------- ویڈیوز ----------
const VIDEO_SELECT = `
  SELECT v.id, v.title, v.description, v.views, v.status, v.created_at,
         u.username, u.display_name,
         (SELECT COUNT(*) FROM likes l WHERE l.video_id = v.id) AS likes,
         EXISTS(SELECT 1 FROM likes l WHERE l.video_id = v.id AND l.user_id = ?) AS liked
  FROM videos v JOIN users u ON u.id = v.user_id`;

const shapeVideo = (r) => ({ ...r, liked: !!r.liked });

function feed(ctx) {
  const page = Math.max(1, parseInt(ctx.query.get('page'), 10) || 1);
  const limit = 10;
  const rows = db
    .prepare(`${VIDEO_SELECT} WHERE v.status = 'published' ORDER BY v.id DESC LIMIT ? OFFSET ?`)
    .all(ctx.user ? ctx.user.id : 0, limit + 1, (page - 1) * limit);
  sendJson(ctx.res, 200, { videos: rows.slice(0, limit).map(shapeVideo), hasMore: rows.length > limit });
}

function canSee(video, user) {
  return video.status === 'published' || (user && (user.id === video.user_id || isStaff(user)));
}

function getVideo(ctx) {
  const id = idParam(ctx.params.id);
  const owner = db.prepare('SELECT user_id, status FROM videos WHERE id = ?').get(id);
  if (!owner || !canSee(owner, ctx.user)) throw new HttpError(404, 'ویڈیو نہیں ملی');
  const row = db.prepare(`${VIDEO_SELECT} WHERE v.id = ?`).get(ctx.user ? ctx.user.id : 0, id);
  sendJson(ctx.res, 200, { video: shapeVideo(row) });
}

const MIME_OK = { 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov' };

// فائل کے شروع کے بائٹس سے اصل فارمیٹ پہچانتے ہیں (صرف نام یا ہیڈر پر بھروسا نہیں)
function looksLikeVideo(file, mime) {
  const fd = fs.openSync(file, 'r');
  const buf = Buffer.alloc(12);
  fs.readSync(fd, buf, 0, 12, 0);
  fs.closeSync(fd);
  if (mime === 'video/webm') return buf.slice(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]));
  return buf.slice(4, 8).toString('latin1') === 'ftyp'; // mp4 / mov
}

async function uploadVideo(ctx) {
  const u = requireUser(ctx);
  rateLimit(`upload:${u.id}`, 20, 60 * 60 * 1000);
  const { req } = ctx;

  const title = str(ctx.query.get('title'));
  const description = str(ctx.query.get('description')).slice(0, 1000);
  if (!title || title.length > 100) throw new HttpError(400, 'عنوان لکھیں (زیادہ سے زیادہ 100 حروف)');

  const mime = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (!MIME_OK[mime]) throw new HttpError(415, 'صرف MP4، WebM یا MOV ویڈیو قبول ہے');

  const declared = parseInt(req.headers['content-length'], 10);
  if (!declared) throw new HttpError(411, 'فائل کا سائز معلوم نہیں');
  if (declared > cfg.MAX_VIDEO_BYTES)
    throw new HttpError(413, `ویڈیو ${Math.round(cfg.MAX_VIDEO_BYTES / 1048576)} MB سے بڑی ہے`);

  const fileName = `${crypto.randomUUID()}.${MIME_OK[mime]}`;
  const dest = path.join(cfg.VIDEO_DIR, fileName);
  let size = 0;
  const limiter = new Transform({
    transform(chunk, _enc, cb) {
      size += chunk.length;
      if (size > cfg.MAX_VIDEO_BYTES) return cb(new HttpError(413, 'ویڈیو بہت بڑی ہے'));
      cb(null, chunk);
    },
  });
  try {
    await pipeline(req, limiter, fs.createWriteStream(dest, { mode: 0o640 }));
    if (!size || !looksLikeVideo(dest, mime)) throw new HttpError(400, 'یہ فائل درست ویڈیو نہیں');
  } catch (e) {
    fs.rmSync(dest, { force: true });
    throw e;
  }

  // سپر ایڈمن کی ویڈیو سیدھی شائع، باقی جانچ کے بعد
  const status = u.role === 'super_admin' ? 'published' : 'review';
  const id = db
    .prepare('INSERT INTO videos (user_id, title, description, file_name, mime, size, status) VALUES (?,?,?,?,?,?,?)')
    .run(u.id, title, description, fileName, mime, size, status).lastInsertRowid;
  sendJson(ctx.res, 201, { id, status });
}

function deleteVideo(ctx) {
  const u = requireUser(ctx);
  const id = idParam(ctx.params.id);
  const v = db.prepare('SELECT id, user_id, file_name FROM videos WHERE id = ?').get(id);
  if (!v) throw new HttpError(404, 'ویڈیو نہیں ملی');
  if (v.user_id !== u.id && !isStaff(u)) throw new HttpError(403, 'آپ کو اجازت نہیں');
  db.prepare('DELETE FROM videos WHERE id = ?').run(id);
  fs.rmSync(path.join(cfg.VIDEO_DIR, v.file_name), { force: true });
  sendJson(ctx.res, 200, { ok: true });
}

function toggleLike(ctx) {
  const u = requireUser(ctx);
  rateLimit(`like:${u.id}`, 120, 60 * 1000);
  const id = idParam(ctx.params.id);
  const v = db.prepare('SELECT id, user_id, status FROM videos WHERE id = ?').get(id);
  if (!v || v.status !== 'published') throw new HttpError(404, 'ویڈیو نہیں ملی');

  const existing = db.prepare('SELECT 1 FROM likes WHERE user_id = ? AND video_id = ?').get(u.id, id);
  if (existing) {
    db.prepare('DELETE FROM likes WHERE user_id = ? AND video_id = ?').run(u.id, id);
  } else {
    db.prepare('INSERT INTO likes (user_id, video_id) VALUES (?, ?)').run(u.id, id);
    notify(v.user_id, 'like', id, u.id);
  }
  const likes = db.prepare('SELECT COUNT(*) AS n FROM likes WHERE video_id = ?').get(id).n;
  sendJson(ctx.res, 200, { liked: !existing, likes });
}

function addView(ctx) {
  const id = idParam(ctx.params.id);
  db.prepare("UPDATE videos SET views = views + 1 WHERE id = ? AND status = 'published'").run(id);
  sendJson(ctx.res, 200, { ok: true });
}

// ویڈیو فائل بھیجنا (Range کے ساتھ، تاکہ آگے پیچھے کرنا چلے)
function streamMedia(ctx) {
  const id = idParam(ctx.params.id);
  const v = db.prepare('SELECT user_id, status, file_name, mime, size FROM videos WHERE id = ?').get(id);
  if (!v || !canSee(v, ctx.user)) throw new HttpError(404, 'ویڈیو نہیں ملی');

  const file = path.join(cfg.VIDEO_DIR, v.file_name);
  if (!fs.existsSync(file)) throw new HttpError(404, 'فائل موجود نہیں');
  const size = fs.statSync(file).size;
  const { req, res } = ctx;
  const base = {
    'Content-Type': v.mime, 'Accept-Ranges': 'bytes',
    'Cache-Control': v.status === 'published' ? 'public, max-age=3600' : 'private, no-store',
  };

  const range = req.headers.range;
  if (!range) {
    res.writeHead(200, { ...base, 'Content-Length': size });
    return fs.createReadStream(file).pipe(res);
  }
  const m = /^bytes=(\d*)-(\d*)$/.exec(range);
  let start, end;
  if (m && (m[1] || m[2])) {
    if (m[1] === '') { start = Math.max(0, size - parseInt(m[2], 10)); end = size - 1; }
    else { start = parseInt(m[1], 10); end = m[2] ? Math.min(parseInt(m[2], 10), size - 1) : size - 1; }
  }
  if (start === undefined || start > end || start >= size) {
    res.writeHead(416, { ...base, 'Content-Range': `bytes */${size}` });
    return res.end();
  }
  res.writeHead(206, {
    ...base, 'Content-Range': `bytes ${start}-${end}/${size}`, 'Content-Length': end - start + 1,
  });
  fs.createReadStream(file, { start, end }).pipe(res);
}

// ---------- پروفائل ----------
function profile(ctx) {
  const target = db
    .prepare('SELECT id, username, display_name, bio, role, status, created_at FROM users WHERE username = ?')
    .get(ctx.params.username);
  if (!target || target.status !== 'active') throw new HttpError(404, 'یہ پروفائل نہیں ملی');

  const viewerId = ctx.user ? ctx.user.id : 0;
  const own = viewerId === target.id;
  const rows = db
    .prepare(`${VIDEO_SELECT} WHERE v.user_id = ? ${own ? '' : "AND v.status = 'published'"} ORDER BY v.id DESC LIMIT 50`)
    .all(viewerId, target.id);
  const totalLikes = db
    .prepare('SELECT COUNT(*) AS n FROM likes l JOIN videos v ON v.id = l.video_id WHERE v.user_id = ?')
    .get(target.id).n;

  sendJson(ctx.res, 200, {
    user: { username: target.username, display_name: target.display_name || target.username, bio: target.bio, role: target.role, created_at: target.created_at },
    totalLikes,
    videos: rows.map(shapeVideo),
  });
}

// ---------- نوٹیفکیشن ----------
function listNotifications(ctx) {
  const u = requireUser(ctx);
  const rows = db
    .prepare(`
      SELECT n.id, n.type, n.video_id, n.is_read, n.created_at,
             f.username AS from_username, v.title AS video_title
      FROM notifications n
      LEFT JOIN users f ON f.id = n.from_user_id
      LEFT JOIN videos v ON v.id = n.video_id
      WHERE n.user_id = ? ORDER BY n.id DESC LIMIT 50`)
    .all(u.id);
  sendJson(ctx.res, 200, { notifications: rows.map((r) => ({ ...r, is_read: !!r.is_read })) });
}

function readNotifications(ctx) {
  const u = requireUser(ctx);
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(u.id);
  sendJson(ctx.res, 200, { ok: true });
}

// ---------- ایڈمن ----------
function adminVideos(ctx) {
  requireStaff(ctx);
  const status = ['review', 'published', 'rejected'].includes(ctx.query.get('status'))
    ? ctx.query.get('status') : 'review';
  const rows = db.prepare(`${VIDEO_SELECT} WHERE v.status = ? ORDER BY v.id DESC LIMIT 100`).all(ctx.user.id, status);
  sendJson(ctx.res, 200, { videos: rows.map(shapeVideo) });
}

function moderateVideo(decision) {
  return (ctx) => {
    const staff = requireStaff(ctx);
    const id = idParam(ctx.params.id);
    const v = db.prepare('SELECT user_id FROM videos WHERE id = ?').get(id);
    if (!v) throw new HttpError(404, 'ویڈیو نہیں ملی');
    const status = decision === 'approve' ? 'published' : 'rejected';
    db.prepare('UPDATE videos SET status = ? WHERE id = ?').run(status, id);
    notify(v.user_id, decision === 'approve' ? 'approved' : 'rejected', id, staff.id);
    sendJson(ctx.res, 200, { ok: true, status });
  };
}

function adminUsers(ctx) {
  requireSuper(ctx);
  const rows = db
    .prepare(`SELECT u.id, u.username, u.email, u.role, u.status, u.created_at,
                     (SELECT COUNT(*) FROM videos v WHERE v.user_id = u.id) AS videos
              FROM users u ORDER BY u.id DESC LIMIT 200`)
    .all();
  sendJson(ctx.res, 200, { users: rows });
}

function setUserStatus(status) {
  return (ctx) => {
    const admin = requireSuper(ctx);
    const id = idParam(ctx.params.id);
    const t = db.prepare('SELECT id, role FROM users WHERE id = ?').get(id);
    if (!t) throw new HttpError(404, 'یوزر نہیں ملا');
    if (t.id === admin.id || t.role === 'super_admin') throw new HttpError(400, 'سپر ایڈمن کو بند نہیں کیا جا سکتا');
    db.prepare('UPDATE users SET status = ? WHERE id = ?').run(status, id);
    sendJson(ctx.res, 200, { ok: true, status });
  };
}

async function setUserRole(ctx) {
  const admin = requireSuper(ctx);
  const id = idParam(ctx.params.id);
  const b = await readJson(ctx.req);
  if (!['user', 'moderator'].includes(b.role)) throw new HttpError(400, 'غلط کردار');
  const t = db.prepare('SELECT id, role FROM users WHERE id = ?').get(id);
  if (!t) throw new HttpError(404, 'یوزر نہیں ملا');
  if (t.id === admin.id || t.role === 'super_admin') throw new HttpError(400, 'سپر ایڈمن کا کردار نہیں بدلا جا سکتا');
  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(b.role, id);
  sendJson(ctx.res, 200, { ok: true, role: b.role });
}

function stats(ctx) {
  requireStaff(ctx);
  const n = (sql) => db.prepare(sql).get().n;
  sendJson(ctx.res, 200, {
    users: n('SELECT COUNT(*) AS n FROM users'),
    videos: n("SELECT COUNT(*) AS n FROM videos WHERE status = 'published'"),
    pending: n("SELECT COUNT(*) AS n FROM videos WHERE status = 'review'"),
    likes: n('SELECT COUNT(*) AS n FROM likes'),
  });
}

// ---------- راستوں کی فہرست ----------
const routes = [
  ['POST', '/api/register', register],
  ['POST', '/api/login', login],
  ['POST', '/api/logout', logout],
  ['GET', '/api/me', me],
  ['PATCH', '/api/me', updateMe],
  ['GET', '/api/videos', feed],
  ['POST', '/api/videos', uploadVideo],
  ['GET', '/api/videos/:id', getVideo],
  ['DELETE', '/api/videos/:id', deleteVideo],
  ['POST', '/api/videos/:id/like', toggleLike],
  ['POST', '/api/videos/:id/view', addView],
  ['GET', '/media/:id', streamMedia],
  ['GET', '/api/users/:username', profile],
  ['GET', '/api/notifications', listNotifications],
  ['POST', '/api/notifications/read', readNotifications],
  ['GET', '/api/admin/stats', stats],
  ['GET', '/api/admin/videos', adminVideos],
  ['POST', '/api/admin/videos/:id/approve', moderateVideo('approve')],
  ['POST', '/api/admin/videos/:id/reject', moderateVideo('reject')],
  ['GET', '/api/admin/users', adminUsers],
  ['POST', '/api/admin/users/:id/ban', setUserStatus('banned')],
  ['POST', '/api/admin/users/:id/unban', setUserStatus('active')],
  ['POST', '/api/admin/users/:id/role', setUserRole],
].map(([method, pattern, fn]) => ({
  method, fn,
  re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'),
}));

function match(method, pathname) {
  let pathMatched = false;
  for (const r of routes) {
    const m = r.re.exec(pathname);
    if (!m) continue;
    pathMatched = true;
    if (r.method === method) return { fn: r.fn, params: { ...m.groups } };
  }
  return pathMatched ? 'method' : null;
}

async function handleApi(req, res, url) {
  const found = match(req.method, url.pathname);
  if (!found) throw new HttpError(404, 'یہ راستہ موجود نہیں');
  if (found === 'method') throw new HttpError(405, 'یہ طریقہ قبول نہیں');

  // CSRF سے بچاؤ: تبدیلی والی ہر درخواست پر ہمارا اپنا ہیڈر لازم ہے
  if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'fetch')
    throw new HttpError(403, 'درخواست قبول نہیں');

  let params = found.params;
  try {
    params = Object.fromEntries(Object.entries(params).map(([k, v]) => [k, decodeURIComponent(v)]));
  } catch {
    throw new HttpError(400, 'غلط ایڈریس');
  }
  await found.fn({ req, res, params, query: url.searchParams, user: currentUser(req) });
}

module.exports = { handleApi };
