'use strict';
// ماحول کی ترتیبات (.env فائل یا سرور کے environment variables سے)
const fs = require('fs');
const path = require('path');

// سادہ .env لوڈر، تاکہ کسی پیکیج کی ضرورت نہ پڑے
(function loadEnvFile() {
  const file = path.join(__dirname, '..', '.env');
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (!m || line.trim().startsWith('#')) continue;
    if (process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
})();

const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
fs.mkdirSync(path.join(DATA_DIR, 'videos'), { recursive: true });

module.exports = {
  PORT: parseInt(process.env.PORT, 10) || 3000,
  DATA_DIR,
  VIDEO_DIR: path.join(DATA_DIR, 'videos'),
  ADMIN_EMAIL: (process.env.ADMIN_EMAIL || '').trim().toLowerCase(),
  MAX_VIDEO_BYTES: (parseInt(process.env.MAX_VIDEO_MB, 10) || 200) * 1024 * 1024,
  TRUST_PROXY: process.env.TRUST_PROXY === '1',
  IS_PROD: process.env.NODE_ENV === 'production',
  SESSION_DAYS: 7,
};
