'use strict';
// فرنٹ اینڈ: ایک ہی صفحہ، راستے # کے ذریعے (#/, #/login, #/u/نام ...)
// نوٹ: یوزر کا لکھا ہوا متن کبھی innerHTML میں نہیں ڈالا جاتا (XSS سے بچاؤ)، صرف textContent

const $app = document.getElementById('app');
const $nav = document.getElementById('nav');
const state = { user: null, unread: 0 };

// ---------- چھوٹے مددگار ----------
function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k in el && k !== 'list') el[k] = v;
    else el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

async function api(method, url, json) {
  const opts = { method, headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' };
  if (json !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(json); }
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(data.error || 'کچھ خرابی ہوئی'); e.status = res.status; throw e; }
  return data;
}

let toastTimer;
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 3000);
}

const fmtDate = (s) => new Date(s.replace(' ', 'T') + 'Z').toLocaleDateString('ur-PK', { year: 'numeric', month: 'short', day: 'numeric' });
const go = (hash) => { location.hash = hash; };

// ---------- اوپر کی پٹی ----------
function renderNav() {
  $nav.replaceChildren();
  const u = state.user;
  if (!u) {
    $nav.append(h('a', { class: 'btn', href: '#/login' }, 'لاگ اِن'), h('a', { class: 'btn primary', href: '#/register' }, 'اکاؤنٹ بنائیں'));
    return;
  }
  $nav.append(
    h('a', { class: 'btn primary', href: '#/upload' }, '＋ ویڈیو'),
    h('a', { class: 'btn', href: '#/notifications' }, 'اطلاعات', state.unread ? h('span', { class: 'badge' }, state.unread) : null),
    h('a', { class: 'btn', href: `#/u/${u.username}` }, 'میری پروفائل'),
    ['moderator', 'super_admin'].includes(u.role) ? h('a', { class: 'btn', href: '#/admin' }, 'ایڈمن') : null,
    h('button', { class: 'btn', onclick: async () => { await api('POST', '/api/logout'); state.user = null; state.unread = 0; renderNav(); go('#/'); toast('آپ لاگ آؤٹ ہو گئے'); } }, 'لاگ آؤٹ')
  );
}

async function loadMe() {
  try {
    const d = await api('GET', '/api/me');
    state.user = d.user; state.unread = d.unread || 0;
  } catch { state.user = null; }
  renderNav();
}

// ---------- ویڈیو کارڈ ----------
function videoCard(v, { onChange } = {}) {
  let viewed = false;
  const likeBtn = h('button', { class: 'btn like' + (v.liked ? ' on' : '') });
  const paint = () => { likeBtn.className = 'btn like' + (v.liked ? ' on' : ''); likeBtn.textContent = `${v.liked ? '♥' : '♡'} ${v.likes}`; };
  paint();
  likeBtn.addEventListener('click', async () => {
    if (!state.user) { toast('لائک کرنے کے لیے پہلے لاگ اِن کریں'); return go('#/login'); }
    try { const r = await api('POST', `/api/videos/${v.id}/like`); v.liked = r.liked; v.likes = r.likes; paint(); }
    catch (e) { toast(e.message); }
  });

  const player = h('video', { controls: true, preload: 'metadata', playsInline: true, src: `/media/${v.id}` });
  player.addEventListener('play', () => { if (!viewed && v.status === 'published') { viewed = true; api('POST', `/api/videos/${v.id}/view`).catch(() => {}); } });

  const canDelete = state.user && (state.user.username === v.username || ['moderator', 'super_admin'].includes(state.user.role));
  return h('article', { class: 'card' },
    h('div', { class: 'video-meta' },
      h('div', {},
        h('h3', { class: 'video-title' }, v.title),
        h('a', { href: `#/u/${v.username}` }, '@' + v.username), ' ',
        h('span', { class: 'muted' }, fmtDate(v.created_at) + ' · ' + v.views + ' بار دیکھی گئی')),
      v.status !== 'published' ? h('span', { class: 'status ' + v.status }, v.status === 'review' ? 'جانچ جاری ہے' : 'مسترد') : null),
    player,
    v.description ? h('p', { class: 'desc' }, v.description) : null,
    h('div', { class: 'actions' }, likeBtn,
      canDelete ? h('button', { class: 'btn danger small', onclick: async () => {
        if (!confirm('کیا واقعی یہ ویڈیو حذف کرنی ہے؟')) return;
        try { await api('DELETE', `/api/videos/${v.id}`); toast('ویڈیو حذف ہو گئی'); onChange && onChange(); } catch (e) { toast(e.message); }
      } }, 'حذف کریں') : null));
}

// ---------- صفحات ----------
async function pageFeed(page = 1) {
  $app.replaceChildren(h('h1', {}, 'تازہ ویڈیوز'));
  const list = h('div'); $app.append(list);
  const more = h('div', { style: 'text-align:center' }); $app.append(more);
  async function load(p) {
    const d = await api('GET', `/api/videos?page=${p}`);
    if (p === 1 && !d.videos.length) list.append(h('div', { class: 'empty' }, 'ابھی کوئی ویڈیو نہیں۔ پہلی ویڈیو آپ اپ لوڈ کریں!'));
    d.videos.forEach((v) => list.append(videoCard(v, { onChange: () => route() })));
    more.replaceChildren();
    if (d.hasMore) more.append(h('button', { class: 'btn', onclick: () => load(p + 1).catch((e) => toast(e.message)) }, 'مزید دکھائیں'));
  }
  await load(page);
}

function authForm(kind) {
  const isReg = kind === 'register';
  const err = h('div', { class: 'error' });
  const form = h('form', { class: 'form', onsubmit: async (e) => {
    e.preventDefault(); err.textContent = '';
    const f = new FormData(form); const btn = form.querySelector('button'); btn.disabled = true;
    try {
      const body = isReg
        ? { username: f.get('username'), email: f.get('email'), password: f.get('password') }
        : { login: f.get('login'), password: f.get('password') };
      await api('POST', isReg ? '/api/register' : '/api/login', body);
      await loadMe(); toast(isReg ? 'اکاؤنٹ بن گیا، خوش آمدید!' : 'خوش آمدید!'); go('#/');
    } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
  } },
    isReg ? h('label', {}, 'یوزر نیم (انگریزی)', h('input', { name: 'username', required: true, minLength: 3, maxLength: 20, pattern: '[A-Za-z0-9_]+', autocomplete: 'username' })) : null,
    isReg ? h('label', {}, 'ای میل', h('input', { name: 'email', type: 'email', required: true, autocomplete: 'email' }))
          : h('label', {}, 'ای میل یا یوزر نیم', h('input', { name: 'login', required: true, autocomplete: 'username' })),
    h('label', {}, 'پاسورڈ' + (isReg ? ' (کم از کم 8 حروف)' : ''), h('input', { name: 'password', type: 'password', required: true, minLength: isReg ? 8 : 1, autocomplete: isReg ? 'new-password' : 'current-password' })),
    err,
    h('button', { class: 'btn primary', type: 'submit' }, isReg ? 'اکاؤنٹ بنائیں' : 'لاگ اِن'));
  $app.replaceChildren(
    h('h1', {}, isReg ? 'نیا اکاؤنٹ' : 'لاگ اِن'),
    h('div', { class: 'card' }, form),
    h('p', { class: 'muted' }, isReg ? 'پہلے سے اکاؤنٹ ہے؟ ' : 'اکاؤنٹ نہیں ہے؟ ',
      h('a', { href: isReg ? '#/login' : '#/register' }, isReg ? 'لاگ اِن کریں' : 'نیا اکاؤنٹ بنائیں')));
}

function pageUpload() {
  if (!state.user) return go('#/login');
  const err = h('div', { class: 'error' });
  const bar = h('progress', { max: 100, value: 0, hidden: true });
  const form = h('form', { class: 'form' },
    h('label', {}, 'ویڈیو فائل (MP4، WebM یا MOV)', h('input', { name: 'file', type: 'file', accept: 'video/mp4,video/webm,video/quicktime', required: true })),
    h('label', {}, 'عنوان', h('input', { name: 'title', required: true, maxLength: 100 })),
    h('label', {}, 'تفصیل (اختیاری)', h('textarea', { name: 'description', rows: 3, maxLength: 1000 })),
    bar, err,
    h('button', { class: 'btn primary', type: 'submit' }, 'اپ لوڈ کریں'));
  form.addEventListener('submit', (e) => {
    e.preventDefault(); err.textContent = '';
    const file = form.file.files[0]; if (!file) return;
    const btn = form.querySelector('button'); btn.disabled = true; bar.hidden = false;
    // XHR استعمال کیا تاکہ اپ لوڈ کی فیصد دکھا سکیں
    const xhr = new XMLHttpRequest();
    const q = new URLSearchParams({ title: form.title.value.trim(), description: form.description.value.trim() });
    xhr.open('POST', '/api/videos?' + q);
    xhr.setRequestHeader('X-Requested-With', 'fetch');
    xhr.setRequestHeader('Content-Type', file.type || 'video/mp4');
    xhr.upload.onprogress = (ev) => { if (ev.lengthComputable) bar.value = (ev.loaded / ev.total) * 100; };
    xhr.onload = () => {
      let d = {}; try { d = JSON.parse(xhr.responseText); } catch { /* خالی */ }
      if (xhr.status === 201) {
        toast(d.status === 'published' ? 'ویڈیو شائع ہو گئی' : 'ویڈیو جمع ہو گئی، جانچ کے بعد شائع ہوگی');
        go(`#/u/${state.user.username}`);
      } else { err.textContent = d.error || 'اپ لوڈ ناکام ہوا'; btn.disabled = false; bar.hidden = true; }
    };
    xhr.onerror = () => { err.textContent = 'انٹرنیٹ کا مسئلہ، دوبارہ کوشش کریں'; btn.disabled = false; bar.hidden = true; };
    xhr.send(file);
  });
  $app.replaceChildren(h('h1', {}, 'نئی ویڈیو اپ لوڈ کریں'), h('div', { class: 'card' }, form),
    h('p', { class: 'muted' }, 'نئی ویڈیو پہلے ایڈمن کی جانچ سے گزرتی ہے، پھر سب کو نظر آتی ہے۔'));
}

async function pageProfile(username) {
  const d = await api('GET', `/api/users/${encodeURIComponent(username)}`);
  const own = state.user && state.user.username === d.user.username;
  const head = h('div', { class: 'profile-head card' },
    h('h1', { style: 'margin:0' }, d.user.display_name), h('div', { class: 'muted' }, '@' + d.user.username),
    d.user.bio ? h('p', { style: 'margin:6px 0' }, d.user.bio) : null,
    h('div', { class: 'stats' }, h('span', {}, `${d.videos.length} ویڈیوز`), h('span', {}, `${d.totalLikes} لائکس`), h('span', {}, 'شامل ہوئے: ' + fmtDate(d.user.created_at))));
  if (own) {
    const name = h('input', { value: d.user.display_name, maxLength: 40 });
    const bio = h('textarea', { rows: 2, maxLength: 300 }, d.user.bio);
    head.append(h('details', {}, h('summary', { class: 'btn small' }, 'پروفائل بدلیں'),
      h('div', { class: 'form', style: 'margin-top:10px' }, h('label', {}, 'نام', name), h('label', {}, 'تعارف', bio),
        h('button', { class: 'btn primary', onclick: async () => {
          try { await api('PATCH', '/api/me', { display_name: name.value, bio: bio.value }); toast('پروفائل محفوظ ہو گئی'); route(); } catch (e) { toast(e.message); }
        } }, 'محفوظ کریں'))));
  }
  $app.replaceChildren(head);
  if (!d.videos.length) $app.append(h('div', { class: 'empty' }, 'ابھی کوئی ویڈیو نہیں'));
  d.videos.forEach((v) => $app.append(videoCard(v, { onChange: () => route() })));
}

const notifText = (n) => {
  const who = '@' + (n.from_username || 'کسی');
  if (n.type === 'like') return `${who} کو آپ کی ویڈیو "${n.video_title}" پسند آئی`;
  if (n.type === 'approved') return `آپ کی ویڈیو "${n.video_title}" منظور ہو کر شائع ہو گئی`;
  if (n.type === 'rejected') return `آپ کی ویڈیو "${n.video_title}" قواعد کے مطابق نہیں تھی، مسترد کر دی گئی`;
  return 'نئی اطلاع';
};

async function pageNotifications() {
  if (!state.user) return go('#/login');
  const d = await api('GET', '/api/notifications');
  $app.replaceChildren(h('h1', {}, 'اطلاعات'));
  if (!d.notifications.length) $app.append(h('div', { class: 'empty' }, 'کوئی اطلاع نہیں'));
  else $app.append(h('div', { class: 'card' }, d.notifications.map((n) =>
    h('div', { class: 'notif' + (n.is_read ? '' : ' unread') }, h('span', {}, notifText(n)), h('span', { class: 'muted' }, fmtDate(n.created_at))))));
  if (state.unread) { await api('POST', '/api/notifications/read'); state.unread = 0; renderNav(); }
}

async function pageAdmin(tab = 'review') {
  if (!state.user || !['moderator', 'super_admin'].includes(state.user.role)) return go('#/');
  const isSuper = state.user.role === 'super_admin';
  const s = await api('GET', '/api/admin/stats');
  const tabs = [['review', 'جانچ کی قطار'], ['published', 'شائع شدہ'], ['rejected', 'مسترد']];
  if (isSuper) tabs.push(['users', 'یوزرز']);
  $app.replaceChildren(
    h('h1', {}, 'ایڈمن پینل'),
    h('div', { class: 'grid-stats' }, [['یوزرز', s.users], ['شائع ویڈیوز', s.videos], ['جانچ باقی', s.pending], ['کل لائکس', s.likes]].map(([k, v]) => h('div', { class: 'card' }, h('b', {}, v), k))),
    h('div', { class: 'tabs' }, tabs.map(([key, label]) => h('button', { class: 'btn' + (key === tab ? ' active' : ''), onclick: () => pageAdmin(key).catch((e) => toast(e.message)) }, label))));

  if (tab === 'users') {
    const d = await api('GET', '/api/admin/users');
    const act = (path, body, msg) => async () => { try { await api('POST', path, body); toast(msg); pageAdmin('users'); } catch (e) { toast(e.message); } };
    $app.append(h('div', { class: 'card table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, ['یوزر', 'ای میل', 'کردار', 'ویڈیوز', 'حالت', 'عمل'].map((t) => h('th', {}, t)))),
      h('tbody', {}, d.users.map((u) => h('tr', {},
        h('td', {}, h('a', { href: `#/u/${u.username}` }, '@' + u.username)),
        h('td', { style: 'direction:ltr;text-align:left' }, u.email),
        h('td', {}, { user: 'عام', moderator: 'موڈریٹر', super_admin: 'سپر ایڈمن' }[u.role]),
        h('td', {}, u.videos),
        h('td', {}, u.status === 'active' ? 'فعال' : 'بین'),
        h('td', {}, u.role === 'super_admin' ? '—' : [
          u.status === 'active'
            ? h('button', { class: 'btn danger small', onclick: () => confirm(`@${u.username} کو بین کریں؟`) && act(`/api/admin/users/${u.id}/ban`, undefined, 'یوزر بین ہو گیا')() }, 'بین')
            : h('button', { class: 'btn small', onclick: act(`/api/admin/users/${u.id}/unban`, undefined, 'بین ہٹا دیا') }, 'بین ہٹائیں'), ' ',
          u.role === 'user'
            ? h('button', { class: 'btn small', onclick: act(`/api/admin/users/${u.id}/role`, { role: 'moderator' }, 'موڈریٹر بنا دیا') }, 'موڈریٹر بنائیں')
            : h('button', { class: 'btn small', onclick: act(`/api/admin/users/${u.id}/role`, { role: 'user' }, 'موڈریٹر ہٹا دیا') }, 'موڈریٹر ہٹائیں')])))))));
    return;
  }

  const d = await api('GET', `/api/admin/videos?status=${tab}`);
  if (!d.videos.length) return $app.append(h('div', { class: 'empty' }, 'اس فہرست میں کوئی ویڈیو نہیں'));
  d.videos.forEach((v) => {
    const card = videoCard(v, { onChange: () => pageAdmin(tab) });
    const decide = (kind, msg) => async () => { try { await api('POST', `/api/admin/videos/${v.id}/${kind}`); toast(msg); pageAdmin(tab); } catch (e) { toast(e.message); } };
    const row = card.querySelector('.actions');
    if (v.status !== 'published') row.append(h('button', { class: 'btn primary small', onclick: decide('approve', 'ویڈیو منظور ہو گئی') }, 'منظور کریں'));
    if (v.status !== 'rejected') row.append(h('button', { class: 'btn danger small', onclick: decide('reject', 'ویڈیو مسترد ہو گئی') }, 'مسترد کریں'));
    $app.append(card);
  });
}

// ---------- راستے ----------
async function route() {
  const hash = location.hash.replace(/^#/, '') || '/';
  const [, a, b] = hash.split('/');
  try {
    if (a === '' || a === undefined) await pageFeed();
    else if (a === 'login') state.user ? go('#/') : authForm('login');
    else if (a === 'register') state.user ? go('#/') : authForm('register');
    else if (a === 'upload') pageUpload();
    else if (a === 'u' && b) await pageProfile(decodeURIComponent(b));
    else if (a === 'notifications') await pageNotifications();
    else if (a === 'admin') await pageAdmin();
    else $app.replaceChildren(h('div', { class: 'empty' }, 'یہ صفحہ نہیں ملا'));
  } catch (e) {
    $app.replaceChildren(h('div', { class: 'empty' }, e.message || 'کچھ خرابی ہوئی'));
  }
  window.scrollTo(0, 0);
}

window.addEventListener('hashchange', route);
loadMe().then(route);
