'use strict';
// تیز جانچ: سرور چلا کر رجسٹر، لاگ اِن، اپ لوڈ، لائک، نوٹیفکیشن اور ایڈمن کو آزماتا ہے
// چلانے کے لیے: npm test
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const PORT = 3900 + Math.floor(Math.random() * 90);
const BASE = `http://localhost:${PORT}`;
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'paktok-test-'));

class Client {
  constructor() { this.cookie = ''; }
  async call(method, url, { json, body, headers = {} } = {}) {
    const h = { 'X-Requested-With': 'fetch', ...headers };
    if (this.cookie) h.Cookie = this.cookie;
    let payload = body;
    if (json !== undefined) { payload = JSON.stringify(json); h['Content-Type'] = 'application/json'; }
    const res = await fetch(BASE + url, { method, headers: h, body: payload, duplex: 'half' });
    const sc = res.headers.get('set-cookie');
    if (sc) this.cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    let data = null;
    try { data = await res.clone().json(); } catch { /* ویڈیو یا صفحہ */ }
    return { status: res.status, data, res };
  }
}

const fakeMp4 = () => Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypisom'), Buffer.alloc(2000, 7)]);

async function waitForServer() {
  for (let i = 0; i < 50; i++) {
    try { await fetch(BASE + '/'); return; } catch { await new Promise((r) => setTimeout(r, 100)); }
  }
  throw new Error('سرور شروع نہیں ہوا');
}

(async () => {
  const server = spawn('node', ['server.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, PORT, DATA_DIR: DATA, ADMIN_EMAIL: 'boss@example.com', MAX_VIDEO_MB: '1' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let serverLog = '';
  server.stdout.on('data', (d) => (serverLog += d));
  server.stderr.on('data', (d) => (serverLog += d));

  const ok = (name) => console.log('  ✓', name);
  try {
    await waitForServer();

    const admin = new Client(), ali = new Client(), sara = new Client(), anon = new Client();

    // رجسٹریشن
    let r = await admin.call('POST', '/api/register', { json: { username: 'boss', email: 'boss@example.com', password: 'password123' } });
    assert.equal(r.status, 201); assert.equal(r.data.user.role, 'super_admin'); ok('ایڈمن ای میل سے سپر ایڈمن بنا');
    r = await ali.call('POST', '/api/register', { json: { username: 'ali', email: 'ali@example.com', password: 'password123' } });
    assert.equal(r.status, 201); assert.equal(r.data.user.role, 'user'); ok('عام یوزر رجسٹر ہوا');
    r = await sara.call('POST', '/api/register', { json: { username: 'sara', email: 'sara@example.com', password: 'password123' } });
    assert.equal(r.status, 201);
    r = await anon.call('POST', '/api/register', { json: { username: 'ALI', email: 'x@example.com', password: 'password123' } });
    assert.equal(r.status, 409); ok('ایک ہی یوزر نیم دوبارہ نہیں بن سکتا');
    r = await anon.call('POST', '/api/register', { json: { username: 'ab', email: 'bad', password: '1' } });
    assert.equal(r.status, 400); ok('غلط معلومات رد ہوئیں');

    // CSRF ہیڈر
    const raw = await fetch(BASE + '/api/logout', { method: 'POST' });
    assert.equal(raw.status, 403); ok('بغیر ہیڈر کے POST رد');

    // لاگ اِن / لاگ آؤٹ
    r = await anon.call('POST', '/api/login', { json: { login: 'ali@example.com', password: 'wrongpass1' } });
    assert.equal(r.status, 401);
    r = await anon.call('POST', '/api/login', { json: { login: 'ali', password: 'password123' } });
    assert.equal(r.status, 200); ok('لاگ اِن (غلط پاسورڈ رد، صحیح قبول)');
    r = await anon.call('GET', '/api/me'); assert.equal(r.data.user.username, 'ali');
    r = await anon.call('POST', '/api/logout'); r = await anon.call('GET', '/api/me');
    assert.equal(r.data.user, null); ok('لاگ آؤٹ');

    // اپ لوڈ
    r = await anon.call('POST', '/api/videos?title=test', { body: fakeMp4(), headers: { 'Content-Type': 'video/mp4' } });
    assert.equal(r.status, 401); ok('بغیر لاگ اِن اپ لوڈ رد');
    r = await ali.call('POST', '/api/videos?title=' + encodeURIComponent('میری پہلی ویڈیو'), { body: Buffer.alloc(3000, 1), headers: { 'Content-Type': 'video/mp4' } });
    assert.equal(r.status, 400); ok('جعلی فائل (ویڈیو نہیں) رد');
    // سرور بڑی فائل پر فوراً 413 دے کر کنکشن بند کر دیتا ہے، اس لیے کلائنٹ کو EPIPE بھی مل سکتا ہے
    try {
      r = await ali.call('POST', '/api/videos?title=' + encodeURIComponent('میری پہلی ویڈیو'), { body: Buffer.alloc(2 * 1048576, 1), headers: { 'Content-Type': 'video/mp4' } });
      assert.equal(r.status, 413);
    } catch (e) {
      if (e.name === 'AssertionError') throw e; // اصل ناکامی
    }
    assert.equal(fs.readdirSync(path.join(DATA, 'videos')).length, 0); ok('حد سے بڑی ویڈیو رد (اور کوئی فائل نہیں بچی)');
    r = await ali.call('POST', '/api/videos?title=' + encodeURIComponent('میری پہلی ویڈیو'), { body: fakeMp4(), headers: { 'Content-Type': 'video/mp4' } });
    assert.equal(r.status, 201); assert.equal(r.data.status, 'review');
    const vid = r.data.id; ok('ویڈیو اپ لوڈ ہوئی (جانچ کی قطار میں)');

    // جانچ سے پہلے عام لوگ نہیں دیکھ سکتے
    r = await anon.call('GET', '/api/videos'); assert.equal(r.data.videos.length, 0);
    r = await sara.call('GET', `/media/${vid}`); assert.equal(r.status, 404);
    r = await ali.call('GET', `/media/${vid}`); assert.equal(r.status, 200); ok('زیرِ جانچ ویڈیو صرف مالک/اسٹاف کو نظر آتی ہے');

    // ایڈمن کی منظوری
    r = await sara.call('POST', `/api/admin/videos/${vid}/approve`); assert.equal(r.status, 403);
    r = await admin.call('GET', '/api/admin/videos?status=review'); assert.equal(r.data.videos.length, 1);
    r = await admin.call('POST', `/api/admin/videos/${vid}/approve`); assert.equal(r.status, 200);
    r = await anon.call('GET', '/api/videos'); assert.equal(r.data.videos.length, 1); ok('ایڈمن نے منظور کی، فیڈ میں آ گئی');

    // Range کے ساتھ پلے بیک
    r = await sara.call('GET', `/media/${vid}`, { headers: { Range: 'bytes=0-99' } });
    assert.equal(r.status, 206);
    assert.equal(r.res.headers.get('content-range'), `bytes 0-99/${fakeMp4().length}`); ok('Range (آگے پیچھے کرنا) چلتا ہے');

    // لائک اور نوٹیفکیشن
    r = await anon.call('POST', `/api/videos/${vid}/like`); assert.equal(r.status, 401);
    r = await sara.call('POST', `/api/videos/${vid}/like`);
    assert.equal(r.data.liked, true); assert.equal(r.data.likes, 1);
    r = await sara.call('POST', `/api/videos/${vid}/like`);
    assert.equal(r.data.liked, false); assert.equal(r.data.likes, 0);
    r = await sara.call('POST', `/api/videos/${vid}/like`); assert.equal(r.data.likes, 1); ok('لائک / ان لائک');

    r = await ali.call('GET', '/api/me'); assert.ok(r.data.unread >= 2); // منظوری + لائک
    r = await ali.call('GET', '/api/notifications');
    const types = r.data.notifications.map((n) => n.type);
    assert.ok(types.includes('like') && types.includes('approved')); ok('مالک کو لائک اور منظوری کی اطلاع ملی');
    await ali.call('POST', '/api/notifications/read');
    r = await ali.call('GET', '/api/me'); assert.equal(r.data.unread, 0); ok('اطلاعات "پڑھی گئی" ہو گئیں');

    // پروفائل
    r = await ali.call('PATCH', '/api/me', { json: { display_name: 'علی خان', bio: 'میں ویڈیوز بناتا ہوں' } });
    assert.equal(r.status, 200);
    r = await anon.call('GET', '/api/users/ali');
    assert.equal(r.data.user.display_name, 'علی خان'); assert.equal(r.data.videos.length, 1); assert.equal(r.data.totalLikes, 1); ok('پروفائل');

    // بین
    r = await admin.call('GET', '/api/admin/users'); const saraRow = r.data.users.find((u) => u.username === 'sara');
    r = await ali.call('POST', `/api/admin/users/${saraRow.id}/ban`); assert.equal(r.status, 403);
    r = await admin.call('POST', `/api/admin/users/${saraRow.id}/ban`); assert.equal(r.status, 200);
    r = await sara.call('GET', '/api/me'); assert.equal(r.data.user, null);
    r = await anon.call('POST', '/api/login', { json: { login: 'sara', password: 'password123' } }); assert.equal(r.status, 403);
    ok('بین شدہ یوزر فوراً بند اور لاگ اِن سے محروم');

    // حذف
    r = await sara.call('DELETE', `/api/videos/${vid}`); assert.equal(r.status, 401);
    r = await ali.call('DELETE', `/api/videos/${vid}`); assert.equal(r.status, 200);
    assert.equal(fs.readdirSync(path.join(DATA, 'videos')).length, 0); ok('ویڈیو اور فائل دونوں حذف');

    // صفحات اور راستے کی حفاظت
    r = await anon.call('GET', '/'); assert.equal(r.status, 200);
    r = await anon.call('GET', '/..%2f..%2fserver.js'); assert.ok([403, 404].includes(r.status)); ok('صفحہ چلتا ہے، ڈائریکٹری سے باہر رسائی بند');

    console.log('\nتمام ٹیسٹ کامیاب ✅');
  } catch (e) {
    console.error('\nٹیسٹ ناکام ❌\n', e);
    console.error('--- سرور لاگ ---\n' + serverLog);
    process.exitCode = 1;
  } finally {
    server.kill();
    fs.rmSync(DATA, { recursive: true, force: true });
  }
})();
