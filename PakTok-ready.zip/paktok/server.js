'use strict';
// سرور کا مرکزی فائل: صرف Node.js، کوئی اضافی پیکیج (npm install) درکار نہیں
const http = require('http');
const fs = require('fs');
const path = require('path');

const cfg = require('./src/config');
const { db } = require('./src/db');
const { handleApi } = require('./src/routes');
const { HttpError, sendJson } = require('./src/http');

const PUBLIC_DIR = path.join(__dirname, 'public');
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8',
};

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; media-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'"
  );
}

function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'یہ طریقہ قبول نہیں');
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { throw new HttpError(400, 'غلط ایڈریس'); }
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  // ڈائریکٹری سے باہر نکلنے کی کوشش (../) روکیں
  if (!file.startsWith(PUBLIC_DIR + path.sep)) throw new HttpError(403, 'اجازت نہیں');
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) throw new HttpError(404, 'صفحہ نہیں ملا');
  res.writeHead(200, {
    'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream',
    'Cache-Control': 'no-cache',
  });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  securityHeaders(res);
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/media/')) {
      await handleApi(req, res, url);
    } else {
      serveStatic(req, res, url.pathname);
    }
  } catch (err) {
    const status = err instanceof HttpError ? err.status : 500;
    if (status === 500) console.error(err);
    if (res.headersSent) return res.destroy();
    const msg = status === 500 ? 'سرور میں خرابی ہوئی' : err.message;
    sendJson(res, status, { error: msg }, status === 413 ? { Connection: 'close' } : {});
  }
});

server.requestTimeout = 0;      // بڑی ویڈیو اپ لوڈ ہونے دیں
server.headersTimeout = 30000;

// جس ای میل کو ADMIN_EMAIL میں لکھا ہے اگر وہ پہلے سے رجسٹر ہے تو اسے سپر ایڈمن بنا دیں
if (cfg.ADMIN_EMAIL) {
  db.prepare("UPDATE users SET role = 'super_admin' WHERE email = ?").run(cfg.ADMIN_EMAIL);
}

server.listen(cfg.PORT, () => {
  console.log(`PakTok چل رہا ہے: http://localhost:${cfg.PORT}`);
  if (!cfg.ADMIN_EMAIL) console.log('تنبیہ: .env میں ADMIN_EMAIL نہیں لکھی، اس لیے کوئی سپر ایڈمن نہیں بنے گا');
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => server.close(() => process.exit(0)));
}
